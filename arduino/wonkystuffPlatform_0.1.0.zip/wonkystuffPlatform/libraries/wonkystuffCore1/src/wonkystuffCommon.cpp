/*****
 * wonkystuffCommon.cpp
 *
 * This file is part of the wonkystuff hardware support package
 * for Arduino and is derived largely from ATTinyCore by Spence Konde
 *
 * This file contains commonly-used definitions
 * that we might need for Core1 purposes.
 *
 * (c) wonkystuff 2021     https://wonkystuff.net/
 *
 *
 */

#include "arduino.h"
#include "wonkystuffCommon.h"

/*
 * General initialisation - enable PLL and wait for
 * it to stabilise before setting it as the source
 * for Timer 1
 */

void
wsInit(void)
{
    // ?
}


// Base-timer is running at 16MHz
#define F_TIM (16000000L)
#define SRATE (20000)

// let the preprocessor calculate the various register values 'coz
// they don't change after compile time
#if ((F_TIM/(SRATE)) < 255)
#define T1_MATCH ((F_TIM/(SRATE))-1)
#define T1_PRESCALE _BV(CS00)  //prescaler clk/1 (i.e. 16MHz)
#else
#define T1_MATCH (((F_TIM/8L)/(SRATE))-1)
#define T1_PRESCALE _BV(CS01)  //prescaler clk/8 (i.e. 2MHz)
#endif

void
wsInitAudioLoop(uint16_t sampleRate)
{
    ///////////////////////////////////////////////
    // Set up Timer/Counter0 for sample-rate ISR
    TCCR0B = 0;                 // stop the timer (no clock source)
    TCNT0 = 0;                  // zero the timer
    TCCR0A = _BV(WGM01);        // CTC Mode
    TCCR0B = T1_PRESCALE;
    OCR0A  = T1_MATCH;          // calculated match value
    TIMSK |= _BV(OCIE0A);

    sei();                      // Enable timer interrupts
}

// Fixed value to start the ADC
// enable ADC, start conversion, prescaler = /64 gives us an ADC clock of 8MHz/64 (125kHz)
#define ADCSRAVAL ( _BV(ADEN) | _BV(ADSC) | _BV(ADPS2) | _BV(ADPS1)  | _BV(ADIE) )

/*
 * We use Timer1 in Fast PWM mode by default,
 * and here's where we set it up.
 */
void
wsInitPWM(void)
{
    PLLCSR |= _BV(PLLE);                // Enable 64 MHz PLL
    delayMicroseconds(100);             // Stabilize
    while (!(PLLCSR & _BV(PLOCK)))
        ;                               // Wait for it...

    PLLCSR |= _BV(PCKE);        // Timer1 source = PLL
    ///////////////////////////////////////////////
    // Set up Timer/Counter1 for 250kHz PWM output
    TCCR1 = 0;                  // stop the timer
    TCNT1 = 0;                  // zero the timer
    GTCCR = _BV(PSR1);          // reset the prescaler
//    TCCR1 = _BV(PWM1A) | _BV(COM1A1) | _BV(COM1A0) | _BV(CS10); // inverted output
    TCCR1 = _BV(PWM1A) | _BV(COM1A1) | _BV(CS10);
    OCR1C = 255;
    OCR1A = 128;                // start with 50% duty cycle on the PWM
    pinMode(PB1, OUTPUT);       // PWM output pin
}

// because we use timer 0, delay() doesn't work - we roll our own
volatile uint32_t ticks = 0;
// This ISR is running at the rate specified by SR (e.g 50kHz)
ISR(wsTimerVector)
{
  ticks++;
  wsAudioLoop();
}

