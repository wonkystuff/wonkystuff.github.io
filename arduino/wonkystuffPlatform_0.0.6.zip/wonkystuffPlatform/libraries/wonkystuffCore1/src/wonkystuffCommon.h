/*****
 * wonkystuffCommon.h
 *
 * This file is part of the wonkystuff hardware support package
 * for Arduino and is derived largely from ATTinyCore by Spence Konde
 *
 * This file contains commonly-used definitions
 * that we might need for Core1 purposes.
 *
 * (c) wonkystuff 2021     https://wonkystuff.net/
 *
 *
 */



