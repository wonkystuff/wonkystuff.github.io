/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */

#include "Arduino.h"
#include "wonkystuffCommon.h"

/*
 * We use Timer1 in Fast PWM mode (250kHz).
 * and here's where we set it up.
 */
void
wsInitPWM(void)
{
    PLLCSR |= _BV(PLLE);                // Enable 64 MHz PLL clock source
    delayMicroseconds(100);             // Stabilize
    while (!(PLLCSR & _BV(PLOCK)))
        ;                               // Wait for it...

    PLLCSR |= _BV(PCKE);                // Timer1 source = PLL

    ///////////////////////////////////////////////
    // Set up Timer/Counter1 for 250kHz PWM output
    TCCR1 = 0;                          // stop the timer
    TCNT1 = 0;                          // zero the timer
    GTCCR = _BV(PSR1);                  // reset the prescaler
//    TCCR1 = _BV(PWM1A) | _BV(COM1A1) | _BV(COM1A0) | _BV(CS10); // inverted output
    TCCR1 = _BV(PWM1A) | _BV(COM1A1) | _BV(CS10);
    OCR1C = 255;
}
