/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */


#ifndef __WONKYSTUFFCOMMON_H__
#define __WONKYSTUFFCOMMON_H__


#ifndef DISABLEMILLIS
#error "millis/micros must be disabled in the Tools menu when using the wonkystuff API."
#endif

#define wsKnob1                     (A0)
#define wsKnob2                     (A1)

// Hardware difference between the standalone Core1.D board
// and the AE modular version.
#if defined AECORE
#define wsKnob3                     (A3)
#define wsKnob4                     (A2)
#elif defined CORE1D
#define wsKnob3                     (A2)
#define wsKnob4                     (A3)
#else
#error Board type not defined!
#endif

#define wsOut1                      (PB1)
#define wsOut2                      (PB0)

#define wsWriteToPWM(val)           OCR1A = (val)
#define wsPinSet(pin)               PORTB |= (1 << pin)
#define wsPinClear(pin)             PORTB &= ~(1 << pin)
#define wsPinWrite(pin,val)         PORTB = (val) ? PORTB | (1 << pin) : PORTB & ~(1 << pin)
#define wsToggleOutput(pin)         PORTB ^= (1 << (pin))

extern const uint16_t               octaveLookup8[1024];
extern const uint16_t               octaveLookup5[1024];
#define wsFetchOctaveLookup8(val)   pgm_read_word(&octaveLookup8[val])
#define wsFetchOctaveLookup5(val)   pgm_read_word(&octaveLookup5[val])
#define wsFetchOctaveLookup(val)    wsFetchOctaveLookup8(val)

extern void        wsInit(void);
extern void        wsInitPWM(void);
extern void        wsInitAudioLoop(void);
extern uint8_t     wsRnd8(void);

// To be implemented by the end-user - this runs at the sample rate.
extern void wsAudioLoop(void);

#endif // __WONKYSTUFFCOMMON_H__