/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */

#include "Arduino.h"
#include "wonkystuffCommon.h"

/*
 * General initialisation - turn the output pins into, ummm, outputs.
 */

void
wsInit(void)
{
  pinMode(wsOut1, OUTPUT);  // output 1
  pinMode(wsOut2, OUTPUT);  // output 2
}
