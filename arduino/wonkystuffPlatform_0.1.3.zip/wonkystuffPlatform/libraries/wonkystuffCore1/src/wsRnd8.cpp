/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */

#include "Arduino.h"
#include "wonkystuffCommon.h"

/*
 * Simple function to give us an 8 bit
 * psuedo-random number sequence.
 * Algorithm from http://doitwireless.com/2014/06/26/8-bit-pseudo-random-number-generator/
 */

uint8_t
wsRnd8(void)
{
  static uint8_t r = 0x23;
  uint8_t lsb = r & 1;
  r >>= 1;
  r ^= (-lsb) & 0xB8;
  return r;
}
