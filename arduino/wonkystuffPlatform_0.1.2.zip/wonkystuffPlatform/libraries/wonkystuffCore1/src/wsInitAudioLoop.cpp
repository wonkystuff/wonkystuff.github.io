/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */


#include "Arduino.h"
#include "wonkystuffCommon.h"

// Base-timer is running at 16MHz
#define F_TIM (16000000L)

// let the preprocessor calculate the various register values 'coz
// they don't change after compile time
#if ((F_TIM/(SRATE)) < 255)
#define MATCH ((F_TIM/(SRATE))-1)
#define PRESCALE _BV(CS00)  _BV(CS00);   // tClk = clk
#elif (((F_TIM/8L)/(SRATE)) < 255)
#define MATCH (((F_TIM/8L)/(SRATE))-1)
#define PRESCALE _BV(CS01)               // tClk = clk/8
#elif (((F_TIM/64L)/(SRATE)) < 255)
#define MATCH (((F_TIM/64L)/(SRATE))-1)
#define PRESCALE _BV(CS01) | _BV(CS00);  // tClk = clk/64
#elif (((F_TIM/256L)/(SRATE)) < 255)
#define MATCH (((F_TIM/256L)/(SRATE))-1)
#define PRESCALE _BV(CS02)               // tClk = clk/256
#elif (((F_TIM/1024L)/(SRATE)) < 255)
#define MATCH (((F_TIM/1024L)/(SRATE))-1)
#define PRESCALE _BV(CS02) | _BV(CS00)  // tClk = clk/1024
#else
#define MATCH 255
#define PRESCALE _BV(CS02) | _BV(CS00)  // tClk = clk/1024
#endif


// because we use timer 0, delay() doesn't work - we roll our own
volatile uint32_t ticks = 0;

void
wsInitAudioLoop(void)
{

    ///////////////////////////////////////////////
    // Set up Timer/Counter0 for sample-rate ISR
    TCCR0B = 0;                 // stop the timer (no clock source)
    TCNT0 = 0;                  // zero the timer
    TCCR0A = _BV(WGM01);        // CTC Mode
    TCCR0B = PRESCALE;
    OCR0A  = MATCH;
    TIMSK |= _BV(OCIE0A);

    sei();                      // Enable timer interrupts
}

// This ISR is running at the rate specified by SR (e.g 50kHz)
ISR(TIM0_COMPA_vect)
{
  ticks++;
  wsAudioLoop();
}

