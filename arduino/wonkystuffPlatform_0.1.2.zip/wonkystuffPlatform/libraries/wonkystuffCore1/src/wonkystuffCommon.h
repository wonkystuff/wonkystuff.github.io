/*
 * Part of the wonkystuff board-support package for the
 * Core1 platform.
 *
 * (c) 2021 wonkystuff https://wonkystuff.net/
 *
 */


#ifndef __WONKYSTUFFCOMMON_H__
#define __WONKYSTUFFCOMMON_H__

#define wsKnob1                     (A0)
#define wsKnob2                     (A1)
#define wsKnob3                     (A2)
#define wsKnob4                     (A3)

#define wsOut1                      (PB1)
#define wsOut2                      (PB0)

#define wsWriteToPWM(val)           OCR1A = (val)
#define wsPinSet(pin)               PORTB |= (1 << pin)
#define wsPinClear(pin)             PORTB &= ~(1 << pin)
#define wsPinWrite(pin,val)         PORTB = (val) ? PORTB | (1 << pin) : PORTB & ~(1 << pin)
#define wsToggleOutput(pin)         PORTB ^= (1 << (pin))

extern const uint16_t               octaveLookup[1024];
#define wsFetchOctaveLookup(val)    pgm_read_word(&octaveLookup[val])

extern void wsInit(void);
extern void wsInitPWM(void);
extern void wsInitAudioLoop(void);

// To be implemented by the end-user - this runs at the sample rate.
extern void wsAudioLoop(void);

extern volatile uint32_t ticks;
#endif // __WONKYSTUFFCOMMON_H__